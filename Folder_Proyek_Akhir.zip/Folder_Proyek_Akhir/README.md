# How to run steamlit app

## Setup Environment

```
pip install numpy pandas matplotlib seaborn streamlit
```

## How to run DASHBOARD

Run file `dashboard.ipynb` in google colab like this:

```
streamlit run dashboard
.py
```
